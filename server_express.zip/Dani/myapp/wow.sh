#!/bin/bash
echo "koceto e gay"
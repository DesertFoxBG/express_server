from weasyprint import HTML

HTML('https://weasyprint.org/about/').write_pdf('./test.pdf')